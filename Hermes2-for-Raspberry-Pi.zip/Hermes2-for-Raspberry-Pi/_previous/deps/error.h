#ifndef __ERROR_H__
#define __ERROR_H__

void exit_with_error( const char* func, char* message );

#endif
