#include "configfile.h"

void empty_configfile() {
}
